<?php
// Examples for Finders

return [
	'google',
	'yandex',
	'torrent',
	'github',
	'asdfasdfasd',
	'Alpha',
	'Beta',
];